<?php
/**
 * PrimeLink – Logo Renderer
 */
defined( 'ABSPATH' ) || exit;

/**
 * Brand logo image URL (cropped from theme assets).
 */
function primelink_brand_logo_url() {
    return get_template_directory_uri() . '/assets/images/logo-brand.png';
}

/**
 * Output the site logo — customizer upload takes precedence, else brand PNG.
 *
 * @param string $context 'header' | 'footer'
 */
function primelink_the_logo( $context = 'header' ) {
    $custom_logo_id = get_theme_mod( 'custom_logo' );
    $class          = 'pl-brand-logo pl-brand-logo--' . esc_attr( $context );
    $alt            = esc_attr( get_bloginfo( 'name' ) );

    if ( $custom_logo_id ) {
        $logo_url = wp_get_attachment_image_url( $custom_logo_id, 'full' );
        if ( $logo_url ) {
            printf(
                '<img src="%s" alt="%s" class="%s" loading="eager" decoding="async">',
                esc_url( $logo_url ),
                $alt,
                esc_attr( $class )
            );
            return;
        }
    }

    printf(
        '<img src="%s" alt="%s" class="%s" loading="eager" decoding="async">',
        esc_url( primelink_brand_logo_url() ),
        $alt,
        esc_attr( $class )
    );
}
